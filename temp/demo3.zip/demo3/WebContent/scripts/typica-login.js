jQuery(document).ready(function($) {

	$.backstretch([
      "bg1.png", 
      "bg2.png"
  	], {duration: 3000, fade: 750});
		
});

