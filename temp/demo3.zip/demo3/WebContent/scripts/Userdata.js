/* User data for auto complete by Justin */
$(function() {
    var availableTags = [
      "Justin",
      "Sura",
      "Jeff",
      "Siva",
      "Howard",
      "Peter",
      "Johnson",
      "Echo",
      "Usher",
      "Frank",
      "Kaylee",
      "Rajkumar",
      "Maheshkuamr",
      "Ernest",
      "Aartee",
      "Owen",
      "Serena",
      "Derek",
      "Chandra",
      "Vijaya",
      "Root",
      "Shaw",
      "Queen",
      "Nathan"
    ];
    $( "#usernamesignup" ).autocomplete({
      source: availableTags
    });
    $( "#username" ).autocomplete({
      source: availableTags
    });
    $( "#usernamechange" ).autocomplete({
      source: availableTags
    });
  });