/* Password Validation by Justin */
function checkForm(form)
  {
    if(form.usernamechange.value == "") {
      alert("Error: username cannot be blank!");
      form.usernamechange.focus();
      return false;
    }
    re = /^\w+$/;
    if(!re.test(form.usernamechange.value)) {
      alert("Error: username must contain only letters, numbers and underscores!");
      form.usernamechange.focus();
      return false;
    }
    if(form.passwordchange.value != "" && form.passwordchange.value == form.passwordchange_confirm.value) {
      if(form.passwordchange.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        form.passwordchange.focus();
        return false;
      }
      if(form.passwordchange.value == form.usernamechange.value) {
        alert("Error: Password must be different from username!");
        form.passwordchange.focus();
        return false;
      }
      re = /[0-9]/;
      if(!re.test(form.passwordchange.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        form.passwordchange.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(form.passwordchange.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        form.passwordchange.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(form.passwordchange.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        form.passwordchange.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      form.passwordchange.focus();
      return false;
    }

    alert("You entered a valid password: " + form.passwordchange.value);
    return true;
  }


$(function(){ 
	$('#passwordchange,#passwordsignup').keyup(function () { 
		var strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g"); 
		var mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g"); 
		var enoughRegex = new RegExp("(?=.{6,}).*", "g"); 
	
		if (false == enoughRegex.test($(this).val())) { 
			$('#level,#level2').removeClass('pw-weak'); 
			$('#level,#level2').removeClass('pw-medium'); 
			$('#level,#level2').removeClass('pw-strong'); 
			$('#level,#level2').addClass(' pw-defule'); 
			 //Low - less than 6
		} 
		else if (strongRegex.test($(this).val())) { 
			$('#level,#level2').removeClass('pw-weak'); 
			$('#level,#level2').removeClass('pw-medium'); 
			$('#level,#level2').removeClass('pw-strong'); 
			$('#level,#level2').addClass(' pw-strong'); 
			 //Max  More than 8 including all 3 
		} 
		else if (mediumRegex.test($(this).val())) { 
			$('#level,#level2').removeClass('pw-weak'); 
			$('#level,#level2').removeClass('pw-medium'); 
			$('#level,#level2').removeClass('pw-strong'); 
			$('#level,#level2').addClass(' pw-medium'); 
			 //Middle More than 7 including 2 of 3 
		} 
		else { 
			$('#level,#level2').removeClass('pw-weak'); 
			$('#level,#level2').removeClass('pw-medium'); 
			$('#level,#level2').removeClass('pw-strong'); 
			$('#level,#level2').addClass('pw-weak'); 
			 //Low - Including all 3  but less than 6 
		} 
		return true; 
	}); 
}) 
