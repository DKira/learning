// check info by Justin 
function checkSignUpForm(form)
  {
    if(form.usernamesignup.value == "") {
      alert("Error: username cannot be blank!");
      form.usernamesignup.focus();
      return false;
    }
    re = /^\w+$/;
    if(!re.test(form.usernamesignup.value)) {
      alert("Error: username must contain only letters, numbers and underscores!");
      form.usernamesignup.focus();
      return false;
    }
    if(form.passwordsignup.value != "" && form.passwordsignup.value == form.passwordsignup_confirm.value) {
      if(form.passwordsignup.value.length < 6) {
        alert("Error: Password must contain at least six characters!");
        form.passwordsignup.focus();
        return false;
      }
      if(form.passwordsignup.value == form.usernamesignup.value) {
        alert("Error: Password must be different from username!");
        form.passwordsignup.focus();
        return false;
      }
      re = /[0-9]/;
      if(!re.test(form.passwordsignup.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        form.passwordsignup.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(form.passwordsignup.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        form.passwordsignup.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(form.passwordsignup.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        form.passwordsignup.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      form.passwordsignup.focus();
      return false;
    }
    return true;
  }
function checkSignoff(){
		var r=confirm("Are you really want to Sign off now?");
		if (r==true)
		  {
		   return true;
		  }
		else
		  {
		    return false;
		  }
}
function vali(){
    var reg = /^(([01]\d|2[0-3]):[0-5]\d)/ig;
    var input = document.getElementById("ptime").value;
    if(reg.test(input))
        return true;
    else
        alert("Wrong time formate!");         
}
function check(){
	var value = document.getElementById("pmem").value;
	var reg=/^[1-9]\d*$|^0$/;
	if(reg.test(value)==true){
	    return true;
	}else{
	    alert("Please insert a number!");
	    return false;
	}
}
function checkDate() {  
	  var reg = /^(\d{2})([-])(\d{2})([-])(\d{4})/;
	  var srcevalue= document.getElementById("pdate").value;
	  if (srcevalue !=null&& !reg.test(srcevalue)) {
	  alert( "Wrong date format, correct example:01-08-2012");  
	  return false;
	  }
}
function Open(){ 
	window.open("/demo3/investments/memfis/jsp/Test.jsp?hdnploc="+document.getElementById("ploc").value);	
}
