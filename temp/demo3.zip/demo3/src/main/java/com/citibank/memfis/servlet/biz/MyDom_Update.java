package com.citibank.memfis.servlet.biz;

import java.io.FileNotFoundException; 
import java.io.FileOutputStream; 
import java.io.IOException; 
 
import javax.xml.parsers.DocumentBuilderFactory; 
import javax.xml.parsers.ParserConfigurationException; 
import javax.xml.transform.Transformer; 
import javax.xml.transform.TransformerConfigurationException; 
import javax.xml.transform.TransformerException; 
import javax.xml.transform.TransformerFactory; 
import javax.xml.transform.dom.DOMSource; 
import javax.xml.transform.stream.StreamResult; 
 
import org.w3c.dom.Document; 
import org.w3c.dom.Element; 
import org.w3c.dom.Node; 
import org.xml.sax.SAXException; 
 
public class MyDom_Update { 

    public void update(String index, int count, String value, boolean outOrno) { 
        Document document = null; 
        try { 
             
            document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse("Information.XML"); 
            Element root = document.getDocumentElement(); 
             
            root.getElementsByTagName(index).item(count).setTextContent(value); 
            output(root, "Information.XML"); 
             
            if (outOrno) { 
                output(root, null); 
            } 
              
        } catch (SAXException e) { 
            // TODO Auto-generated catch block  
            e.printStackTrace(); 
        } catch (IOException e) { 
            // TODO Auto-generated catch block  
            e.printStackTrace(); 
        } catch (ParserConfigurationException e) { 
            // TODO Auto-generated catch block  
            e.printStackTrace(); 
        } 
    } 
     
      public static void output(Node node, String filename) { 
            TransformerFactory transFactory = TransformerFactory.newInstance(); 
            try { 
              Transformer transformer = transFactory.newTransformer(); 
              //transformer.setOutputProperty("encoding", "gb2312"); 
              //transformer.setOutputProperty("indent", "yes"); 
              DOMSource source = new DOMSource(); 
              source.setNode(node); 
              StreamResult result = new StreamResult(); 
              if (filename == null) { 
                result.setOutputStream(System.out); 
              } else { 
                result.setOutputStream(new FileOutputStream(filename)); 
              } 
              transformer.transform(source, result); 
            } catch (TransformerConfigurationException e) { 
              e.printStackTrace(); 
            } catch (TransformerException e) { 
              e.printStackTrace(); 
            } catch (FileNotFoundException e) { 
              e.printStackTrace(); 
            } 
          } 
} 
