package com.citibank.memfis.dao.impl;

import com.citibank.memfis.bean.UserInfo;
import com.citibank.memfis.dao.UserDAO;


public class UserDAOImpl implements UserDAO {

	@Override
	public UserInfo checkUser(String strUserName, String strPwd)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserInfo updateUser(String strUserName, String strPwd)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserInfo addUser(String strUserName, String strPwd) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
}