package com.citibank.memfis.servlet.biz;
//BlockingQueue for read the record from XML and write the record start program.
import java.io.FileNotFoundException;  
import java.io.FileReader;
import java.io.IOException;  
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import java.io.File;
import java.io.FileOutputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
 
import org.dom4j.Branch;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;
public class ReadUsersInformation {  
  
    public  Information login(String Username, String pwd) throws SAXException,   
            FileNotFoundException, IOException {  
	    	List<Information> infoList = ReadInfoXml.readInfoFromXml();
	    	Information info = new Information();
	        for(int i=0;i<infoList.size();i++){
	        	Information C = infoList.get(i);
	        	System.out.println(info);
	        	String A = C.getUserName();
	        	String B = C.getPassWord();
	    
	        	if((Username).equalsIgnoreCase(A)&& (pwd).equalsIgnoreCase(B)){
	        		 info.setFlag("Y");
	        		 break;
	        	}
	        	else if((Username).equalsIgnoreCase(A) && !(pwd).equalsIgnoreCase(B)){
	        		info.setFlag("NA");		    
	        		System.out.println("User Information is invalid!");
	        		break;
	        	}else{
	        		info.setFlag("N");
	        		System.out.println("User Information is invalid!");
	        	}
	  
	        }
	      	return info;
    }

	
}