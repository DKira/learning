package com.citibank.memfis.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citibank.memfis.util.PartyUtil;

@RestController
public class PartyController {
	
	@RequestMapping("/listParty")
    public PartyList listParty() {
        return  PartyUtil.listParty();
    }
	
	@RequestMapping("/viewParty")
    public Attendees viewParty(@RequestBody Party party) {
        return  PartyUtil.viewAttendees(party.getPname());
    }
	
	@RequestMapping("/deleteParty")
	public String deleteParty(@RequestBody Party party) {
		return PartyUtil.deleteParty(party.getPname());
    }
	
	@RequestMapping("/addParty")
	public String addParty(@RequestBody Party party) {
		return PartyUtil.addParty(party);
    }
	
	@RequestMapping("/updateParty")
	public String updateParty(@RequestBody Party party) {
		return PartyUtil.updateParty(party);
    }
	
	
}
