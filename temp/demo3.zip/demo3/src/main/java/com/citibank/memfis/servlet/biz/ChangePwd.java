package com.citibank.memfis.servlet.biz;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Attribute;
import org.dom4j.Branch;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.dom4j.tree.DefaultElement;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

import com.citibank.memfis.util.StringUtil;

public class ChangePwd {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws SAXException 
	 * @throws FileNotFoundException 
	 * @throws SAXNotSupportedException 
	 * @throws SAXNotRecognizedException 
	 */
        public Information  changepwd(String username, String pwdOld, String pwd) throws SAXNotRecognizedException, SAXNotSupportedException, FileNotFoundException, SAXException, IOException {
		// TODO Auto-generated method stub

        SAXReader reader1 = new SAXReader();
        try {
        	 org.dom4j.Document document=null;
			try {
				document = (org.dom4j.Document) reader1.read(new InputSource(new FileReader("Information.XML")));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			Information info= new Information();
	    	List<Information> infoList = ReadInfoXml.readInfoFromXml();
	    		  for(int i=0;i<infoList.size();i++){
	  	    		Information A = infoList.get(i);
	  	    		if((username).equalsIgnoreCase(A.getUserName()) && !(pwdOld).equalsIgnoreCase(A.getPassWord()))
	  	    		{
	  	    		    info.setFlag("Z");
		        		 System.out.println("User old pwd not right!");
		        		 break;	  	    			
	  	    		}
	  	    		if((username).equalsIgnoreCase(A.getUserName()) && (pwd).equalsIgnoreCase(A.getPassWord()))
	  	    		{
		        		 info.setFlag("X");
		        		 System.out.println("Userpwd can not be changed as before!");
		        		 break;
		        	}	  	    		
	  	    		else if((username).equalsIgnoreCase(A.getUserName())){
		        		 info.setFlag("Y");
		        		 MyDom_Update mUpdate = new MyDom_Update();
		                   mUpdate.update("PassWord", i, pwd, false);
		        		 break;
		        	}		        
		        	else
		        	{
		        		info.setFlag("Q");	
		        		System.out.println("UserName not in xml!");
		        	}
	    		  }
	    		  return info;	        	           
        } catch (DocumentException e) {
            e.printStackTrace();
        }
		return null;
	}
}