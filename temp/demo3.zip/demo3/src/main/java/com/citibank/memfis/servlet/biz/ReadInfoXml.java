package com.citibank.memfis.servlet.biz;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.citibank.memfis.util.Constants;

public class ReadInfoXml {  

  public static List<Information> readInfoFromXml() throws SAXException,
			SAXNotRecognizedException, SAXNotSupportedException, IOException,
			FileNotFoundException {
		System.out.println("get the record from the XML...");
		//Created to deal with the document content for related event processor 
		MyContentHandler contentHandler = new MyContentHandler();  
		//contentHandler.setInvList(queue);
		//Created to deal with the error for related event processor 
		ErrorHandler errorHandler = new MyErrorHandler();  
		//Create DTD
		DTDHandler dtdHandler = new MyDTDHandler();  
		//Create Entity Resolver
		EntityResolver entityResolver = new MyEntityResolver();  
		//Create XML reader 
		XMLReader reader = XMLReaderFactory.createXMLReader();   
		/* 
		 *     http://xml.org/sax/features/validation = true Open the validation feature 
		 *     http://xml.org/sax/features/namespaces = true open namespaces feature
		 */  
		reader.setFeature("http://xml.org/sax/features/validation",true);  
		reader.setFeature("http://xml.org/sax/features/namespaces",true);  
		//Set content handler
		reader.setContentHandler(contentHandler);  
		//Set Error Handler  
		reader.setErrorHandler(errorHandler);  
		//Set DTD
		reader.setDTDHandler(dtdHandler);  
		//Set Entity Resolver 
		reader.setEntityResolver(entityResolver);  
		//Reader the document
		reader.parse(new InputSource(new FileReader(Constants.xmlUrl))); 
		
		List<Information> infoList = contentHandler.getInfoList();
		return infoList;
	}  
}