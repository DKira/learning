package com.citibank.memfis.servlet.biz;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.dom4j.Branch;
import org.dom4j.DocumentException;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.dom4j.tree.DefaultElement;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

import com.citibank.memfis.util.StringUtil;

public class test {
	
	public static void main (String[] args){
		for(int i=0;i<3;i++){
			System.out.println("i: "+i);
			for (int j=0;j<3;j++){
				System.out.println("j: "+j);
				break;
			}
			break;
		}
		
		
	}
	
	
}

