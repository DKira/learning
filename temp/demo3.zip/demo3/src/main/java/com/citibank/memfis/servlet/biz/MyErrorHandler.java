package com.citibank.memfis.servlet.biz;

import org.xml.sax.ErrorHandler;  
import org.xml.sax.SAXException;  
import org.xml.sax.SAXParseException;  
  
public class MyErrorHandler implements ErrorHandler {  
  
    /* 
     * recoverable message 
     */  
    @Override  
    public void error(SAXParseException e) throws SAXException {  
        System.err.println("Error ("+e.getLineNumber()+","  
                +e.getColumnNumber()+") : "+e.getMessage());  
    }  
      
    /* 
     * unrecoverable message
     */  
    @Override  
    public void fatalError(SAXParseException e) throws SAXException {  
        System.err.println("FatalError ("+e.getLineNumber()+","  
                +e.getColumnNumber()+") : "+e.getMessage());  
    }  
  
    /* 
     * unrecoverable warning message
     */  
    @Override  
    public void warning(SAXParseException e) throws SAXException {  
        System.err.println("Warning ("+e.getLineNumber()+","  
                +e.getColumnNumber()+") : "+e.getMessage());  
    }  
  
}  