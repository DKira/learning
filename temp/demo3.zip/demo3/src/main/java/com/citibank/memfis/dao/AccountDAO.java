package com.citibank.memfis.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.citibank.memfis.bean.UserInfo;

public class AccountDAO {
	
	public static void main(String[] args){
		AccountDAO account = new AccountDAO();
		//System.out.println(account.checkUser("Usher", "123"));
		account.addUser("Justin", "123");
	}
	
    public String checkUser(String strUserName, String strPwd) {
    	Connection conn = null;
        Statement ps = null;
        ResultSet rs = null;
        String result = "";
        conn = DAO.getDB2Connection();
        String sql = "select * from FE_USER where username = '"+strUserName+"' and password = '" + strPwd + "'";
        try {
                ps = conn.createStatement();
                rs = ps.executeQuery(sql);
                
                if(rs.next()){
                	result = "Y";
                } else {
                	result = "N";
                }

        } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        }finally {
        	try {
				ps.close();
	        	conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        return result;

    }


    public String updateUser(String strUserName,String strOldPwd, String strPwd){
    	Connection conn = null;
        Statement ps = null;
        ResultSet rs = null;
        String result = "";
        conn = DAO.getDB2Connection();
        String querysql = "select * from FE_USER where username = '"+strUserName+"' and password = '" + strOldPwd+"'";
        System.out.println(querysql);
        try {
        	if(isRecordExist(conn,querysql)){
        		String sql = "update FE_USER set password ="+strPwd+" where username = "+strUserName;
                ps = conn.createStatement();
                ps.executeUpdate(sql);
                result = "Y";
        	}
        } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        }finally {
        	try {
				ps.close();
	        	conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        return result;
    }

    public String addUser(String strUserName, String strPwd) {
    	Connection conn = null;
        Statement ps = null;
        String result = "";
        conn = DAO.getDB2Connection();
        String querysql = "select * from FE_USER where username ='"+strUserName+"'";
        result = "H";
        try {
        	if(!isRecordExist(conn,querysql)){
        		String sql = "insert into FE_USER values ('"+strUserName+"','"+strPwd+"')";
        		System.out.println(sql);
                ps = conn.createStatement();
                ps.executeUpdate(sql);
                result = "Y";
        	}

        } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        } finally {
        	try {
				ps.close();
	        	conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        return result;

    }
    private boolean isRecordExist(Connection conn, String querySql) throws SQLException {
    	Statement stmt = conn.createStatement();
    	ResultSet results = stmt.executeQuery(querySql);
    	boolean result = results.next();
    	stmt.close();
    	return result;
    }

}
