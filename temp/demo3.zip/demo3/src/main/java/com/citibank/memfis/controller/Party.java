package com.citibank.memfis.controller;



public class Party {
	
	private  long id;	
	private  String pname = "";
    private  String pdate = "";
    private  String ptime = "";
    private  String ploc = "";
    private  String pmem = "";
    private  String ppay = "";
    private  String premarks = "";
    private  String pattendes = "";
    
    public Party() {	
		
	}
    
    public Party(long id, String pname, String pdate, String ptime, String ploc, String pmem, String ppay,
			String premarks, String pattendes) {	
		this.id = id;
		this.pname = pname;
		this.pdate = pdate;
		this.ptime = ptime;
		this.ploc = ploc;
		this.pmem = pmem;
		this.ppay = ppay;
		this.premarks = premarks;
		this.pattendes = pattendes;
	}
    
    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPdate() {
		return pdate;
	}

	public void setPdate(String pdate) {
		this.pdate = pdate;
	}

	public String getPtime() {
		return ptime;
	}

	public void setPtime(String ptime) {
		this.ptime = ptime;
	}

	public String getPloc() {
		return ploc;
	}

	public void setPloc(String ploc) {
		this.ploc = ploc;
	}

	public String getPmem() {
		return pmem;
	}

	public void setPmem(String pmem) {
		this.pmem = pmem;
	}

	public String getPpay() {
		return ppay;
	}

	public void setPpay(String ppay) {
		this.ppay = ppay;
	}

	public String getPremarks() {
		return premarks;
	}

	public void setPremarks(String premarks) {
		this.premarks = premarks;
	}

	public String getPattendes() {
		return pattendes;
	}

	public void setPattendes(String pattendes) {
		this.pattendes = pattendes;
	}   
    

}
