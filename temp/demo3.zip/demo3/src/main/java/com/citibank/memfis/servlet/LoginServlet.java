package com.citibank.memfis.servlet;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;

import com.citibank.memfis.base.BaseServlet;
import com.citibank.memfis.bean.UserInfo;
import com.citibank.memfis.dao.AccountDAO;
import com.citibank.memfis.dao.DaoFactory;
import com.citibank.memfis.dao.UserDAO;
import com.citibank.memfis.servlet.biz.ChangePwd;
import com.citibank.memfis.servlet.biz.Information;
import com.citibank.memfis.servlet.biz.ReadUsersInformation;
import com.citibank.memfis.servlet.biz.Register;
import com.citibank.memfis.util.StringUtil;
import com.citibank.memfis.util.SysConstants;
import com.citibank.memfis.util.SysTag;

public class LoginServlet extends BaseServlet implements SysTag{
	
	private static final long serialVersionUID = 1L;
	private static Logger _log = Logger.getLogger(LoginServlet.class);
	
	UserDAO userDao = (UserDAO) DaoFactory.getInstance().getDAO("userDAO");
	@Override
	public void processAction(HttpServletRequest request,
			HttpServletResponse response) throws FileNotFoundException, SAXException, IOException, ServletException {
		// TODO Auto-generated method stub
		_log.info("Into LoginServlet.processAction()");
		ActionType = StringUtil.emptyString(request.getParameter(Tag_Type));
		_log.info("Type:"+ActionType);
		if ((SysConstants.METHOD_LOGIN).equalsIgnoreCase(ActionType)) {
			BootstrapLogin(request, response);
		}else if((SysConstants.METHOD_SIGNUP).equalsIgnoreCase(ActionType)){
			register(request, response);
		}else if((SysConstants.METHOD_CHANGE).equalsIgnoreCase(ActionType)){
			changepwd(request, response);
		}		
		else if((SysConstants.METHOD_SIGHOFF).equalsIgnoreCase(ActionType)){
			signoff(request, response);
		}
	}
    private void BootstrapLogin(HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, SAXException, IOException, ServletException {
    	_log.info("Into LoginServlet.processAction() BootstrapLogin - in");
    	ReadUsersInformation loginInfo = new ReadUsersInformation();
    	AccountDAO accountDao = new AccountDAO();
    	//Information infoReply = new Information();
    	//infoReply = loginInfo.login(request.getParameter("username"), request.getParameter("password"));
    	String infoReply=accountDao.checkUser(request.getParameter("username"), request.getParameter("password"));
    	//String FlagReply = StringUtil.emptyString(infoReply.getFlag());
    	request.setAttribute("inFoReply", infoReply);
    	request.setAttribute("User", request.getParameter("username"));
    	request.getSession().setAttribute("User", request.getParameter("username"));
    	if("Y".equalsIgnoreCase(infoReply))
    	{
    		addCookie(request.getParameter("username"),request.getParameter("password"),response,request);
    		request.getRequestDispatcher("/investments/memfis/jsp/in.jsp").forward(request,response);
    	}
    	else
    	{  
    		request.getRequestDispatcher("/investments/memfis/jsp/BootstrapLogin.jsp").forward(request,response);  
    	}
    	_log.info("Into LoginServlet.processAction() BootstrapLogin - out");
    }
    private void register(HttpServletRequest request, HttpServletResponse response) throws SAXNotRecognizedException, SAXNotSupportedException, FileNotFoundException, SAXException, IOException, ServletException {
    	_log.info("Into LoginServlet.processAction() register - in");
    //	Register register = new Register();
    	AccountDAO accountDao = new AccountDAO();
    	//Information infoReply = new Information();
    	//infoReply = register.signup(request.getParameter("usernamesignup"), request.getParameter("passwordsignup"));
    	String infoReply=accountDao.addUser(request.getParameter("usernamesignup"), request.getParameter("passwordsignup"));
    	//String FlagReply = StringUtil.emptyString(infoReply.getFlag());
    	request.setAttribute("inFoReply", infoReply);
    	if("H".equalsIgnoreCase(infoReply)){
    		request.getRequestDispatcher("/investments/memfis/jsp/BootstrapLogin.jsp").forward(request,response);
    	}
    	else
    	{  
    		request.getRequestDispatcher("/investments/memfis/jsp/BootstrapLogin.jsp").forward(request,response); 
    	}
    	_log.info("Into LoginServlet.processAction() register - out");
    }
    private void changepwd(HttpServletRequest request, HttpServletResponse response) throws SAXNotRecognizedException, SAXNotSupportedException, FileNotFoundException, SAXException, IOException, ServletException{
    	_log.info("Into LoginServlet.processAction() changepwd - in");
    	//ChangePwd chaPwd = new ChangePwd();
    	//Information infoReply = new Information();
    	//infoReply = chaPwd.changepwd(request.getParameter("usernamechange"), request.getParameter("passwordold"),request.getParameter("passwordchange"));
    	//String FlagReply = StringUtil.emptyString(infoReply.getFlag());
    	AccountDAO accountDao = new AccountDAO();
    	String infoReply = accountDao.updateUser(request.getParameter("usernamechange"), request.getParameter("passwordold"),request.getParameter("passwordchange"));
    	request.setAttribute("inFoReply", infoReply);
    	if("Q".equalsIgnoreCase(infoReply)){
    		request.getRequestDispatcher("/investments/memfis/jsp/BootstrapLogin.jsp").forward(request,response);
    	}
    	else if("X".equalsIgnoreCase(infoReply)){
    		request.getRequestDispatcher("/investments/memfis/jsp/BootstrapLogin.jsp").forward(request,response);
    	}
    	else
    	{  
    		request.getRequestDispatcher("/investments/memfis/jsp/BootstrapLogin.jsp").forward(request,response); 
    	}
    	_log.info("Into LoginServlet.processAction() changepwd - out");
    }
    private void signoff(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	_log.info("Into LoginServlet.processAction() signoff - in");
    	if(request.getAttribute("User")!=null)
    	{
    		_log.info("Into LoginServlet.processAction() removeAttr - in");
    		request.removeAttribute("User");  		
    		request.getRequestDispatcher("/investments/memfis/jsp/BootstrapLogin.jsp").forward(request,response); 
    		_log.info("Into LoginServlet.processAction() removeAttr - out");
    	}
    	else{
    	request.getRequestDispatcher("/investments/memfis/jsp/BootstrapLogin.jsp").forward(request,response); 
    	}
    	_log.info("Into LoginServlet.processAction() signoff - out");
    }
    private void addCookie(String name, String password,HttpServletResponse response, HttpServletRequest request) throws UnsupportedEncodingException {  
        if(!"".equalsIgnoreCase(name)&&!"".equalsIgnoreCase(password)){  
            //create Cookie  
            Cookie nameCookie=new Cookie("username",URLEncoder.encode(name,"utf-8"));  
            Cookie pswCookie=new Cookie("psw",password);  
              
            //create cookie father path
            nameCookie.setPath(request.getContextPath()+"/"); //Below Was webapp all folders can use this cookie
            pswCookie.setPath(request.getContextPath()+"/");  

            String rememberMe=request.getParameter("loginkeeping");  
            if(rememberMe==null){ 
                nameCookie.setMaxAge(0);  
                pswCookie.setMaxAge(0);  
            }else{
                nameCookie.setMaxAge(7*24*60*60);  
                pswCookie.setMaxAge(7*24*60*60);  
            }  
            response.addCookie(nameCookie);  
            response.addCookie(pswCookie);  
        }  
    }  
	@Override
	public void printLog(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}	
}