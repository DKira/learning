package com.citibank.memfis.filter;

import org.apache.catalina.filters.RemoteIpFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.citibank.memfis.controller.CORSFilter;

@Configuration
public class WebApplication {
    @Bean
    public CORSFilter remoteIpFilter() {
        return new CORSFilter();
    }
}