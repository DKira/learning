package com.citibank.memfis.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import org.apache.log4j.Logger;

public class DaoFactory {
	
	private static Logger _log = Logger.getLogger(DaoFactory.class);
	
	 private static DaoFactory instance = new DaoFactory();
	    private static Properties pro;
	  
	    private DaoFactory() {
	    	_log.info("Initalize DaoFactory start.");
	        try {   
	            pro = new Properties();     
	            InputStream inputStream = DaoFactory.class.getClassLoader()   
	                    .getResourceAsStream("daoConfig.properties");
	            pro.load(inputStream);   
	        } catch (IOException e) {
	        	_log.error("Initalize DaoFactory error "+e.getMessage());
	            throw new ExceptionInInitializerError(e);
	        }
	        _log.info("Initalize DaoFactory successful end.");
	    }   
	  
	    public static DaoFactory getInstance() {   
	        return instance;   
	    }   

	    public Object getDAO(String Key) {   
	        String className = (String) pro.get(Key);   
	        try {
				return (Class.forName(className).newInstance());
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return className;   
	    }   
	} 