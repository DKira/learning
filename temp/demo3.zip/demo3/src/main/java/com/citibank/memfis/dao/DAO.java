package com.citibank.memfis.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DAO {
	public static Connection getDB2Connection(){
		String url = "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ="+"C:\\Users\\wl69412\\Documents\\workspace-sts-3.7.2.RELEASE\\Test\\src\\MemfTools.mdb";
		Connection conn = null;
	    try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		    conn = DriverManager.getConnection(url);  
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	        
	    return conn;
	}
}
