package com.citibank.memfis.controller;

import java.util.ArrayList;

public class Attendees {
	
	private  ArrayList attendees;

	public ArrayList getAttendees() {
		return attendees;
	}

	public void setAttendees(ArrayList attendees) {
		this.attendees = attendees;
	}

	

	

}
