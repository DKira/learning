package com.citibank.memfis.controller;

import java.util.ArrayList;

public class PartyList {
	
	public ArrayList getPartyList() {
		return partyList;
	}

	public void setPartyList(ArrayList partyList) {
		this.partyList = partyList;
	}

	private  ArrayList partyList;

	
}
