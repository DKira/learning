package com.citibank.memfis.servlet.biz;

public class Information {
	private String strUserName;
	private String strPassWord;
	private String strFlag;
	
	public String getUserName() {
		return strUserName;
	}
	public void setUserName(String userName) {
		strUserName = userName;
	}
	public String getPassWord() {
		return strPassWord;
	}
	public String getFlag() {
		return strFlag;
	}
	public void setFlag(String flag) {
		strFlag = flag;
	}
	public void setPassWord(String passWord) {
		strPassWord = passWord;
	}
	@Override
	public String toString() {
		return "Information [strUserName=" + strUserName + ", strPassWord=" + strPassWord + "]";
	}
	
}
