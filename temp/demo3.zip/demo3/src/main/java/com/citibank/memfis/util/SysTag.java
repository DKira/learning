package com.citibank.memfis.util;

public interface SysTag {
	
	String Tag_Type = "Type";
	String Tag_UserLogin = "username";
	String Tag_LoginPwd = "password";
	
	
	
}