package com.citibank.memfis.servlet.biz;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import org.xml.sax.Attributes;  
import org.xml.sax.ContentHandler;  
import org.xml.sax.Locator;  
import org.xml.sax.SAXException;  
  
class MyContentHandler implements ContentHandler{  
    StringBuffer jsonStringBuffer ;  
    private List<Information> infoList = null;
    private Information info = null;
   
	public List<Information> getInfoList() {
		return infoList;
	}
	public void setInfoList(List<Information> infoList) {
		this.infoList = infoList;
	}
	boolean bUserName = false;
    boolean bPassWord = false;
   
    int frontBlankCount = 0;  
    int queueCount = 0;
    public MyContentHandler(){  
        jsonStringBuffer = new StringBuffer();  
    }  
    /* 
     * Accept the char record message for data. 
     * ch[begin:end]: nodeValue in DOM. 
     */  
    @Override  
    public void characters(char[] ch, int begin, int length) throws SAXException {  
        StringBuffer buffer = new StringBuffer();  
        for(int i = begin ; i < begin+length ; i++){  
            switch(ch[i]){  
                case '\\':buffer.append("\\\\");break;  
                case '\r':buffer.append("\\r");break;  
                case '\n':buffer.append("\\n");break;  
                case '\t':buffer.append("\\t");break;  
                case '\"':buffer.append("\\\"");break;  
                default : buffer.append(ch[i]);   
            }  
        }  
        if (bUserName) {
            info.setUserName(new String(ch, begin, length));
            bUserName = false;
        } else if (bPassWord) {
            info.setPassWord(new String(ch, begin, length));
            bPassWord = false;
        }
    }  
    /* 
     * when document end. 
     */  
    @Override  
    public void endDocument() throws SAXException {  
    }  
    /*  when end the element 
     *    uri ：Elements of the namespace 
     *    localName ：Elements of the local name(No prefix) 
     *    qName ：Elements of the Qualified name(prefix) 
     */  
    @Override  
    public void endElement(String uri,String localName,String qName)  
            throws SAXException {  
        if (qName.equalsIgnoreCase("User")) {
        	infoList.add(info);
			System.out.println("Producer queueCount: "+(++queueCount));
        }
    }  
    /* 
     * End the prefix URI mapping. 
     */  
    @Override  
    public void endPrefixMapping(String prefix) throws SAXException {  
    }  
    /* 
     * Can blank Elements of content.
     *     ch : CHar form XML document. 
     *     start : Start of the array.
     *     length : read the char length form the array.
     */  
    @Override  
    public void ignorableWhitespace(char[] ch, int begin, int length)  
            throws SAXException {  
        StringBuffer buffer = new StringBuffer();  
        for(int i = begin ; i < begin+length ; i++){  
            switch(ch[i]){  
                case '\\':buffer.append("\\\\");break;  
                case '\r':buffer.append("\\r");break;  
                case '\n':buffer.append("\\n");break;  
                case '\t':buffer.append("\\t");break;  
                case '\"':buffer.append("\\\"");break;  
                default : buffer.append(ch[i]);   
            }  
        }  
    }  
    /* 
     * Receiving a processing command to inform 
     *     target : processing command target 
     *     data : processing command data, if not provide, then it is null. 
     */  
    @Override  
    public void processingInstruction(String target,String data)  
            throws SAXException {  
    }  
    /* 
     *Find the event object for the document
     *     locator : Can return any SAX events document location of the object 
     */  
    @Override  
    public void setDocumentLocator(Locator locator) {  
    }  
    /* 
     * skipped Entity 
     *     name : the name of skipped Entity. if it is the argument Entity the name will start with '%', 
     *            if it is the child of DTD.it will be the string of "[dtd]" 
     */  
    @Override  
    public void skippedEntity(String name) throws SAXException {  
    }  
    /* 
     *document begin. 
     */  
    @Override  
    public void startDocument() throws SAXException {  
    }  
    /* 
     * Elements Begin 
     *    uri ：name space
     *    localName ：local name 
     *    qName ：Name 
     *    atts ：Attrbuilte
     */  
    @Override  
    public void startElement(String uri, String localName, String qName,   
            Attributes atts) throws SAXException {  
        if (qName.equalsIgnoreCase("User")) {
            info = new Information();
            if (infoList == null)
            	infoList =  new ArrayList<Information>();
        } else if (qName.equalsIgnoreCase("UserName")) {
        	bUserName = true;
        } else if (qName.equalsIgnoreCase("PassWord")) {
        	bPassWord = true;
        }
    }  
    /* 
     * Began to prefix the URI name space scope mapping. 
     * it is not mandatory for the usual name space. 
     * when http://xml.org/sax/features/namespaces default value is true 
     * SAX XML reader will replace the element and attribute name prefix automatically. 
     */  
    @Override  
    public void startPrefixMapping(String prefix,String uri)  
            throws SAXException {  
    }  
    private String toBlankString(int count){  
        StringBuffer buffer = new StringBuffer();  
        for(int i = 0;i<count;i++)  
            buffer.append("    ");  
        return buffer.toString();  
    }  
}  
