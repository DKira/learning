package com.citibank.memfis.util;

public class SysConstants {
	
	public static final String METHOD_LOGIN = "login";
	public static final String METHOD_CHANGE = "changepwd";
	public static final String METHOD_SIGNUP = "signup";
	public static final String METHOD_SIGHOFF = "signoff";
	
}