package com.citibank.memfis.util;

public class Constants {
	public static String xmlUrl = "C:\\Users\\wl69412\\Documents\\workspace-sts-3.7.2.RELEASE\\demo3\\src\\main\\java\\com\\citibank\\memfis\\userinfo\\Information.XML";
}
