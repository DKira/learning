package com.citibank.memfis.dao;

import com.citibank.memfis.bean.UserInfo;

public interface UserDAO{
	
	public UserInfo checkUser(String strUserName,String strPwd)throws Exception;
	public UserInfo updateUser(String strUserName,String strPwd)throws Exception;
	public UserInfo addUser(String strUserName,String strPwd) throws Exception;
	
}