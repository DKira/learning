package com.citibank.memfis.servlet.biz;

import java.io.IOException;  

import org.xml.sax.EntityResolver;  
import org.xml.sax.InputSource;  
import org.xml.sax.SAXException;  
  
public class MyEntityResolver implements EntityResolver {  
  
    /* 
     * Allows applications to parse an external entity. 
	* parser will open any external entities (except for top-level document entity) before this method is called 
	* parameters meaning is as follows: 
	* publicId: cited public identifier of an external entity, if you do not provide, is null. 
	* systemId: the referenced external entity system identifier. 
	* returns: 
	* a new input source InputSource object description, or returns null, 
     */  
    @Override  
    public InputSource resolveEntity(String publicId, String systemId)  
            throws SAXException, IOException {  
        return null;  
    }  
  
}  