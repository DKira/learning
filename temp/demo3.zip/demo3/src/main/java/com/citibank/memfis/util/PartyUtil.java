package com.citibank.memfis.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.citibank.memfis.controller.Attendee;
import com.citibank.memfis.controller.Attendees;
import com.citibank.memfis.controller.Party;
import com.citibank.memfis.controller.PartyList;
import com.citibank.memfis.dao.DAO;

public class PartyUtil {
	
	public static PartyList listParty()
	{
		Connection mdbconn = null;
		Statement sta = null;
		ResultSet partyRs = null;
		
		PartyList partyLs = new PartyList();
		ArrayList pls = new ArrayList();
		
		try{
			mdbconn = DAO.getDB2Connection();		
			sta = mdbconn.createStatement();  
			StringBuffer querybuff = new StringBuffer();
			querybuff.append("select * from PARTY");
		    partyRs = sta.executeQuery(querybuff.toString());	        
	        
	        System.out.println("list query generated :-"+ querybuff.toString());
	        
	        if(partyRs.next()){
	        	Party party = new Party();
                System.out.println(partyRs.getString("pname"));
                System.out.println(partyRs.getString("pdate	")); 
                System.out.println(partyRs.getString("ptime"));
                
                System.out.println(partyRs.getString("ploc"));
                System.out.println(partyRs.getString("pmem")); 
                System.out.println(partyRs.getString("ppay"));  
                
                System.out.println(partyRs.getString("premarks"));
                System.out.println(partyRs.getString("pattendees"));
                               
                
                party.setPname(partyRs.getString("pname"));
                party.setPdate(partyRs.getString("pdate"));
                party.setPtime(partyRs.getString("ptime"));
                
                party.setPloc(partyRs.getString("ploc"));
                party.setPmem(partyRs.getString("pmem"));                
                party.setPpay(partyRs.getString("ppay"));
                
                party.setPdate(partyRs.getString("premarks"));                
                party.setPdate(partyRs.getString("pattendes"));
                pls.add(party);
            }
	        System.out.println("listParty-->"+pls);
	        partyLs.setPartyList(pls);
		}catch(Exception e)
		{
			System.out.println("listParty-->"+ e.getLocalizedMessage());
		}finally{
			if(partyRs!=null)
				partyRs=null;
			if(sta!=null)
				sta=null;
			if(mdbconn!=null)
				mdbconn=null;
			
		}
		return partyLs;
	}
	
	public static String addParty(Party party)
	{
		String added ="N";
		Connection mdbconn = null;
		Statement sta = null;		
		
		try{		
			mdbconn = DAO.getDB2Connection();		
			sta = mdbconn.createStatement();  
			StringBuffer querybuff = new StringBuffer();
			querybuff.append("INSERT INTO PARTY(pname,pdate,ptime,ploc,pmem,ppay,premarks,pattendees) VALUES('").append(party.getPname());
			querybuff.append("','").append(party.getPdate()).append("','").append(party.getPtime()).append("','").append(party.getPloc());
			querybuff.append("','").append(party.getPmem()).append("','").append(party.getPpay()).append("','").append(party.getPremarks());
			querybuff.append("','").append(party.getPattendes()).append("')");
			
				
			
			System.out.println("insert query generated for party insert:-"+ querybuff.toString());
			
	        int partyRs = sta.executeUpdate(querybuff.toString());	
	        
	        System.out.println("No of party added :-"+ partyRs);  
	        
	        String[] attendees = null;
			if(party.getPattendes().contains(",")){
				attendees = party.getPattendes().split(",");
			
			
				for(int i =0;i<attendees.length;i++)
				{
					String attendee = (String)attendees[i];
					StringBuffer querybuffAttendee = new StringBuffer();
					querybuffAttendee.append("INSERT INTO ATTENDEE(attendeename,party,status) VALUES('");
					querybuffAttendee.append(attendee).append("','").append(party.getPname()).append("','N'");
					
					System.out.println("insert query generated for attendee insert:-"+ querybuffAttendee.toString());
					
					int attendeeRs = sta.executeUpdate(querybuffAttendee.toString());	
			        
			        System.out.println("No of attendee added :-"+ attendeeRs); 
				}
			}
	        
			added ="Y";	
	        
		}catch(Exception e)
		{
			System.out.println("addParty-->"+ e.getLocalizedMessage());
		}finally{			
			if(sta!=null)
				sta=null;
			if(mdbconn!=null)
				mdbconn=null;
			
		}
		return added;
	}
	
	public static Attendees viewAttendees(String party)
	{
		Attendees attendees = new Attendees();		
		ArrayList pls = new ArrayList();
		
		Connection mdbconn = null;		
		Statement sta = null; 
		ResultSet partyRs = null;	 
		
		try{		
			mdbconn = DAO.getDB2Connection();		
			sta = mdbconn.createStatement();  
			StringBuffer querybuff = new StringBuffer();
			querybuff.append("select * from ATTENDEE WHERE party='").append(party).append("'");
	        partyRs = sta.executeQuery(querybuff.toString());	        
	        
	        System.out.println("view query generated :-"+ querybuff.toString());
	        
	        if(partyRs.next()){
                System.out.println(partyRs.getString("attendeename"));
                System.out.println(partyRs.getString("party")); 
                System.out.println(partyRs.getString("status")); 
                
                Attendee attendee = new Attendee();
                
                attendee.setAttendee(partyRs.getString("attendeename"));
                attendee.setPname(partyRs.getString("party"));
                attendee.setStatus(partyRs.getString("status"));
                pls.add(attendee);
            }
	        attendees.setAttendees(pls);
	        System.out.println("view Attendees list-->"+pls);
		}catch(Exception e)
		{
			System.out.println("viewAttendees-->"+ e.getLocalizedMessage());
		}finally{
			if(partyRs!=null)
				partyRs=null;
			if(sta!=null)
				sta=null;
			if(mdbconn!=null)
				mdbconn=null;
			
		}
		return attendees;
	}
	
	public static String deleteParty(String party)
	{
		String deleted ="N";
		Connection mdbconn = null;		
		Statement sta = null;  
		
		try{		
			mdbconn = DAO.getDB2Connection();		
			sta = mdbconn.createStatement();  
			StringBuffer querybuff = new StringBuffer();
			querybuff.append("DELETE from ATTENDEE WHERE party='").append(party).append("'");
			
			System.out.println("delete query generated for attendee table :-"+ querybuff.toString());
			
	        int partyRs = sta.executeUpdate(querybuff.toString());	
	        System.out.println("No of attendees Deleted from attendee table :-"+ partyRs); 
	        
	        querybuff = new StringBuffer();
	        querybuff.append("DELETE from PARTY WHERE pname='").append(party).append("'");			
			System.out.println("delete query generated for party table :-"+ querybuff.toString());
			
			partyRs = sta.executeUpdate(querybuff.toString());
			
	        System.out.println("No of party Deleted from party table :-"+ partyRs);   
	        
	        deleted ="Y";
		}catch(Exception e)
		{
			System.out.println("deleteParty-->"+ e.getLocalizedMessage());
		}finally{			
			if(sta!=null)
				sta=null;
			if(mdbconn!=null)
				mdbconn=null;
			
		}
		return deleted;	
	}
	
	public static String updateParty(Party party)
	{
		String updated ="N";
		Connection mdbconn = null;		
		Statement sta = null;  
		
		try{		
			mdbconn = DAO.getDB2Connection();		
			sta = mdbconn.createStatement();  
			StringBuffer querybuff = new StringBuffer();		
			
			querybuff.append("DELETE from ATTENDEE WHERE party='").append(party.getPname()).append("'");
			
			System.out.println("delete query generated :-"+ querybuff.toString());
	        
			int partyRs = sta.executeUpdate(querybuff.toString());
			
	        System.out.println("No of Attendes Delete :-"+ partyRs);  
	        
	        querybuff = new StringBuffer();
	        querybuff.append("DELETE from PARTY WHERE pname='").append(party).append("'");			
			System.out.println("delete query generated for party table :-"+ querybuff.toString());
			
			partyRs = sta.executeUpdate(querybuff.toString());
			
	        System.out.println("No of party Deleted from party table :-"+ partyRs); 
	        
	        
	        
	        querybuff.append("INSERT INTO PARTY(pname,pdate,ptime,ploc,pmem,ppay,premarks,pattendees) VALUES('").append(party.getPname());
			querybuff.append("','").append(party.getPdate()).append("','").append(party.getPtime()).append("','").append(party.getPloc());
			querybuff.append("','").append(party.getPmem()).append("','").append(party.getPpay()).append("','").append(party.getPremarks());
			querybuff.append("','").append(party.getPattendes()).append("')");
			
				
			
			System.out.println("insert query generated for party insert:-"+ querybuff.toString());
			
	        int partyupdaters = sta.executeUpdate(querybuff.toString());	
	        
	        System.out.println("No of party updated :-"+ partyupdaters);  
	        
	        String[] updateattendees = null;
			if(party.getPattendes().contains(","))
				updateattendees = party.getPattendes().split(",");
			
			
			for(int i =0;i<updateattendees.length;i++)
			{
				String attendee = (String)updateattendees[i];
				StringBuffer querybuffAttendee = new StringBuffer();
				querybuffAttendee.append("INSERT INTO ATTENDEE(attendeename,party,status) VALUES('");
				querybuffAttendee.append(attendee).append("','").append(party.getPname()).append("','N'");
				
				System.out.println("insert query generated for attendee insert for update:-"+ querybuffAttendee.toString());
				
				int attendeeRs = sta.executeUpdate(querybuffAttendee.toString());	
		        
		        System.out.println("No of attendee added for update :-"+ attendeeRs); 
			}
			
			updated ="Y";  
		}catch(Exception e)
		{
			System.out.println("updateParty-->"+ e.getLocalizedMessage());
		}finally{			
			if(sta!=null)
				sta=null;
			if(mdbconn!=null)
				mdbconn=null;
			
		}
		return updated;
	}

}
