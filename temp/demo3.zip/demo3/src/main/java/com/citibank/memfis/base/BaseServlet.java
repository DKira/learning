package com.citibank.memfis.base;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.citibank.memfis.util.SysTag;
import org.apache.log4j.Logger;
import org.xml.sax.SAXException;

/**
* @ClassName: BaseServlet
* @Description: this is the base servlet,all sevlet must extends it.
* @author zl99924
* @date May 5, 2014 10:45:56 AM
* 
*/
public abstract class BaseServlet extends HttpServlet implements SysTag{
	private static final long serialVersionUID = 1L;
	private static Logger _log = Logger.getLogger(BaseServlet.class);

	public static String ActionType;
	
	
	/**
	* @Title: processAction
	* @author: QY32778
	* @Description: process action.
	* @param request
	* @param response
	* @return void
	 * @throws ServletException 
	 * @throws IOException 
	 * @throws SAXException 
	 * @throws FileNotFoundException 
	*/ 
	public abstract void processAction(HttpServletRequest request, HttpServletResponse response) throws FileNotFoundException, SAXException, IOException, ServletException;
	
	/**
	* @Title: printLog
	* @author: QY32778
	* @Description: print the servlet log.
	* @param request
	* @param response
	* @return void
	*/ 
	public abstract void printLog(HttpServletRequest request, HttpServletResponse response);
       
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		_log.info("Into BaseServlet.service.");		
		response.setCharacterEncoding("UTF-8");				
		String strIp = request.getRemoteAddr();
		printLog(request, response);	
		try {
			processAction(request, response);
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		_log.info("Out BaseServlet.service()");
	}
	
}
