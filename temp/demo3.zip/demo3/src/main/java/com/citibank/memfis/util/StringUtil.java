package com.citibank.memfis.util;



public class StringUtil implements SysTag{
	

	
	public static String emptyString(String strValue) {
		if (strValue == null) {
			return "";
		} else if (strValue.trim().length() <= 0) {
			return "";
		} else if (strValue.trim().equalsIgnoreCase("null")) {
			return "";
		} else
			return trim(strValue);
	}
	
	private static String trim(String value) {
		int len = value.length();
		int count = value.length();
		int st = 0;
		int off = 0; 
		char[] val = value.toCharArray(); 
		while ((st < len) && (((int) val[off + st]) == 32 || ((int) val[off + st]) == 0)) {
			st++;
		}
		while ((st < len) && (((int) val[off + len - 1]) == 32 || ((int) val[off + len - 1]) == 0)) {
			len--;
		}
		return ((st > 0) || (len < count)) ? value.substring(st, len) : value;
	}
}
