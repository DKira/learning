package com.citibank.memfis.servlet.biz;

import org.xml.sax.DTDHandler;  
import org.xml.sax.SAXException;  
  
public class MyDTDHandler implements DTDHandler {  
  
    /* 
     *Receive comments statement event notification. 
	* parameters meaning is as follows: 
	* the name - the annotation name. 
	* publicId - comments public identifier, if not, it is null. 
	* systemId - annotation system identifier, if not, it is null. 
     */  
    @Override  
    public void notationDecl(String name, String publicId, String systemId)  
            throws SAXException {  
        System.out.println(">>> notation declare : (name = "+name  
                +",systemId = "+publicId  
                +",publicId = "+systemId+")");  
    }  
  
    /* 
		* receive unparsed entity declaration event notification. 
		* parameters meaning is as follows: 
		*The name of the * name - an unparsed entity. 
		* publicId - the entity's public identifier, if not, it is null. 
		* systemId - the entity's system identifier. 
		The name of the * notationName - related comments.. 
     */  
    @Override  
    public void unparsedEntityDecl(String name,  
            String publicId,  
            String systemId,  
            String notationName) throws SAXException {  
        System.out.println(">>> unparsed entity declare : (name = "+name  
                +",systemId = "+publicId  
                +",publicId = "+systemId  
                +",notationName = "+notationName+")");  
    }  
  
}  
