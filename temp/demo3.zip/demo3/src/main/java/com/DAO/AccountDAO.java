package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.Pojo.Account;

public class AccountDAO {
	public static Account getAccountById(String id){
		Connection conn = null;
		Statement ps = null;
		ResultSet rs = null;

		Account account = new Account();
		conn = DAO.getDB2Connection();
		
		String sql = "select * from FE_ROLE where roleId = " + id;
		try {
			ps = conn.createStatement();
			rs = ps.executeQuery(sql);
			
			if(rs.next()){
				account.setId(id);
				account.setName(rs.getString("roleName"));
				account.setDesc(rs.getString("roleDesc"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return account;
	}
}
