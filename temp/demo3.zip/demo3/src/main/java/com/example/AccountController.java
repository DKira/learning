package com.example;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.DAO.AccountDAO;
import com.Pojo.Account;

@RestController
public class AccountController {
	@RequestMapping("/getAccountById")
	public Account getAccountById(@RequestBody String id){
		Account account = AccountDAO.getAccountById(id);
		
		return account;
		
	}
}
