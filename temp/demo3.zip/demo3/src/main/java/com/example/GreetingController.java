package com.example;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMethod;

@RestController
public class GreetingController {

    private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();

    @RequestMapping("/greeting")
    public Greeting greeting(@RequestBody User user) {
        return new Greeting(counter.incrementAndGet(),
                            String.format(template, user.getName()));
    }
    
    @RequestMapping(value="/hello",method = RequestMethod.GET)
    public String printHello(Model model) {
    	System.out.println("in controller");
       model.addAttribute("message", "Hello Spring MVC Framework!");
       return "index";
    }
}