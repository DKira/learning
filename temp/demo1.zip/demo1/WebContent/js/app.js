//两个函数：AppView和TodoView。前者需要在页面加载的时候进行实例化，它的代码才会执行。
//我们可以通过jQuery的ready()函数实现这个目的。在DOM加载中，执行以下函数


var app = app || {};
  var ENTER_KEY = 13;
  var ESC_KEY = 27;

  $(function() {

    // Kick things off by creating the **App**.
    new app.AppView();

  });