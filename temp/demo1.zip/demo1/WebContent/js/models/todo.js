//确保app始终是一个非空的对象
var app = app || {};



  // Todo Model
  // ----------
  // 一个todo有两个属性，一个是用于保持todo项标题的title，还有就是用于标识其是否完成的completed。

  app.Todo = Backbone.Model.extend({

    // Default attributes ensure that each todo created has `title` and `completed` keys.
    defaults: {
      title: '',
      completed: false
    },

    // 通过toggle()方法，可以设置并保持一个todo项完成的状态
    toggle: function() {
      this.save({
        completed: !this.get('completed')
      });
    }

  });
