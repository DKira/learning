var app = app || {};

  // Todo Item View
  // --------------

  //  TodoView实例将和单个独立的todo记录相关联。以确保todo更新的时候view也进行相应地更新。
  //  在启用该功能时，需要在视图上添加事件监听器，在todo的HTML显示上监听事件。
  //The DOM element for a todo item...
  app.TodoView = Backbone.View.extend({

    //... is a list tag.
    tagName: 'li',

    // Cache the template function for a single item.
    template: _.template( $('#item-template').html() ),

    // The DOM events specific to an item.
    events: {
      'click .toggle':'togglecompleted',
    	
    	
     //用户双击todo列表中的一个现有的todo项时，edit()将当前项的查看模式切换成编辑模式，以便用户可以修改当前todo项的title属性。
      'dblclick label': 'edit', 
      'click .destroy': 'clear',
      
      //updateOnEnter()检查用户是否按了回车键，然后执行close()函数
      'keypress .edit': 'updateOnEnter',
      'keydown .edit' : 'revertOnEscape',
      
      //将<input/> 元素字段的文本值的前后空格进行过滤。确保如果不输入任何其他文本则不进行处理。
      //如果提供的值有效，则将该值保持至当前Todo模型，并且通过移除相应的CSS类关闭编辑模型。
      'blur .edit': 'close'
    },

    // 在initialize()构造函数里，我们设置了一个监听器，用于监听Todo模型的change事件。
    //其结果是：todo更新时，应用程序会渲染重新渲染视图，并且直观的反应器变化，
    //注意，Todo模型是通过AppView在arguments参数里面传递进来的，并且在this.model上自动调用。？？？？？？？？？
    initialize: function() {
      this.listenTo(this.model, 'change', this.render);
      this.listenTo(this.model, 'destroy', this.remove);        
      this.listenTo(this.model, 'visible1', this.toggleVisible); 
    },

    // 在render()方法中，使用Underscore.js渲染#item-template，该模板之前通过Underscore的_.template()方法编译到this.template里。
    //返回的HTML片段将替换视图元素(基于tagName属性隐式创建的li元素)的内容。
    //渲染之后的模板现在是在this.el下，并且可以附加在用户界面的todo列表里。将实例化模板里的input元素缓存在this.input后，render()方法结束。
    render: function() {
      this.$el.html( this.template( this.model.toJSON() ) );
      //根据模型的completed状态在该元素上切换completed样式。
      this.$el.toggleClass( 'completed', this.model.get('completed') ); 
      this.toggleVisible();                                             

      this.$input = this.$('.edit');
      return this;
    },             

    // toggleVisible()方法判断todo项是否应该可见，并进行相应的更新。
    
    
    //toggleClass() 对设置或移除被选元素的一个或多个类进行切换。
    //该方法检查每个元素中指定的类。如果不存在则添加类，如果已设置则删除之。这就是所谓的切换效果。
    //不过，通过使用 "switch" 参数，您能够规定只删除或只添加类。
    //$(selector).toggleClass(class,switch)
    //class:必需。规定添加或移除 class 的指定元素。如需规定若干 class，请使用空格来分隔类名。
    //switch:可选。布尔值。规定是否添加或移除 class。

    toggleVisible : function () {
      this.$el.toggleClass( 'hidden',  this.isHidden());
    },

    // NEW - Determines if item should be hidden
    //判断todo项是否应该可见，并进行相应的更新
    isHidden : function () {
      var isCompleted = this.model.get('completed');
      return ( // hidden cases only
        (!isCompleted && app.TodoFilter === 'completed')
        || (isCompleted && app.TodoFilter === 'active')
      );
//    	return this.model.get('completed')?
//    			app.TodoFilter === 'active' :
//    			app.TodoFilter === 'completed';
    },

    // 选中todo项的checkbox复选框时发生的事件
    //(1)togglecompleted()函数被调用，该函数会调用Todo模型上的toggle()方法。
    //(2)toggle()切换所选的todo项的完成状态，并调用Todo模型上的save()方法。
    togglecompleted: function() {
    	
    	//调用todo.js中的toggle方法
      this.model.toggle();
    },

    // Switch this view into `"editing"` mode, displaying the input field.
    //edit()用户双击todo列表中的一个todo项时，edit()将当前项的查找模式切换成编辑模型，以便用户可以修改当前todo项的title属性
    //addClass() 方法向被选元素添加一个或多个类。该方法不会移除已存在的 class 属性，仅仅添加一个或多个 class 属性。
    edit: function() {
      this.$el.addClass('editing');//多几个class属性，让显示处于编辑状态
      this.$input.focus();
    },

    // Close the `"editing"` mode, saving changes to the todo.
    //将<input/>元素字段的文本值的前后空格过滤掉，确保如果不输入任何其他文本则不进行处理，
    //如果提供的值有效，则将该值保持在当前Todo模型，并且通过移除相应的css类关闭编辑模型。
    close: function() {
    	
//    if(!this.$el.hasClass('editing')){
//    	return;
//    }
      var value = this.$input.val().trim();

      if ( value ) {
        this.model.save({ title: value });
      } else {
        this.clear(); 
      }

      this.$el.removeClass('editing');
    },
    
    
    //检查用户是否按了回车键，然后执行close()方法。
    // If you hit `enter`, we're through editing the item.
    updateOnEnter: function( e ) {
      if ( e.which === ENTER_KEY ) {
        this.close();
      }
    },
    revertOnEscape: function(e){
    	if(e.which === ESC_KEY ){
    		this.$el.removeClass('editing');
    		this.$input.val(this.model.get('title'));
    	}
    },

    // NEW - Remove the item, destroy the model from *localStorage* and delete its view.
    clear: function() {
      this.model.destroy();
    }
  });