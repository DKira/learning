var app = app || {};


  // ---------------

  //  AppView将负责处理新todo项的创建和初始todo列表的渲染     Our overall **AppView** is the top-level piece of UI.
  app.AppView = Backbone.View.extend({

	//el属性保存id为todoapp的DOM元素的一个应用  。el指向index.html里面的<section id="todoapp"/>元素。
    el: '#todoapp',

    //使用Underscore微模型的_.template调用，从#stats-template模板构建了一个statsTemplate对象，稍后在渲染视图的时候，我们会使用到该模板。
    statsTemplate: _.template( $('#stats-template').html() ),

    // 为DOM事件定义一个包含申明式回调式的events哈希，它将这些事件捆绑到了如下方法。
  
    events: {
      'keypress #new-todo': 'createOnEnter',
      'click #clear-completed': 'clearCompleted',
      'click #toggle-all': 'toggleAllComplete'
    },

    // initialize()方法用于从localStorage获取之前保存的todo项。
    initialize: function() {
    	
    //使用jQuery将元素缓存到局部变量上。（this.$()查找的是this.$el上相关的元素）
      this.allCheckbox = this.$('#toggle-all')[0];//选中所有的选择框
      this.$input = this.$('#new-todo');
      this.$footer = this.$('#footer');
      this.$main = this.$('#main');
      this.$list=$('#todo-list');//new
    //在Todo上捆绑了两个事件，add和reset 更新和删除操作，我们是委托给TodoView视图进行处理的。
      
      //当add事件被触发时，addone()方法被调用，并传入新的模型。addone()创建一个TodoView实例，并进行渲染，然后将渲染的结果附加到todo列表中
      this.listenTo(app.Todos, 'add', this.addOne);
      //当reset事件被触发时（从localStorage加载todo数据，批量更新集合时），addAll()方法被调用，并对当前的集合的所有todo进行迭代。
      //然后触发每一个todo项的addOne()方法。
      this.listenTo(app.Todos, 'reset', this.addAll);

      // 在Todo集合上的change:completed事件绑定在一个filterOne()回调，该绑定监听集合中任意一个模型的completed标记,
      //受影响的todo会传入给该回调，该回调会在该模型上触发一个visible自定义事件。
      this.listenTo(app.Todos, 'change:completed', this.filterOne);
      
      //为filter事件捆绑了一个filterAll()回调，工作方式有点像addOne()和addAll()。
      //它的职责是：通过调用filterOne()，让UI页面上符合选择条件（all，completed，remaining）的todo项变成可见。
      this.listenTo(app.Todos,'filter', this.filterAll);
      
      //使用特殊的all事件将Todos集合上触发的任何事件绑定至视图的渲染方式。
      this.listenTo(app.Todos, 'all', this.render);
       
     // this.listenTo(app.Todos, 'all', _.debounce(this.render,0));//new
      //collections.fetch()通过发送HTTP GET请求到URL上，从服务器上获取JSON数组形式的模型数据集。一旦数据接收，Backbone将执行set()函数来更新集合。
      app.Todos.fetch({reset:true});//new {reset:true}
    },

    // #main和#footer部分的显示和隐藏，取决于集合中是否包含todo项。
    render: function() {
      var completed = app.Todos.completed().length;
      var remaining = app.Todos.remaining().length;

      if ( app.Todos.length ) {
        this.$main.show();
        this.$footer.show();

        //footer页面的HTML代码的填充，是由statsTemplate以及已完成todo项的数字completed和未完成的数字remaining产生的。
        this.$footer.html(this.statsTemplate({
          completed: completed,
          remaining: remaining
        }));

        
        //footer的HTML里包含了一系列的过滤链接，app.TodoFilter的值将由我们的路由来设置。
        //用于将所选的样式类应用于与目前所选择的过滤条件对应的链接条目上，其结果是将条件式css样式应用于该过滤条件。
        this.$('#filters li a')
          .removeClass('selected')
          .filter('[href="#/' + ( app.TodoFilter || '' ) + '"]')
          .addClass('selected');
      } else {
        this.$main.hide();
        this.$footer.hide();
      }

      //allCheckbox的更新取决于是否还有剩余的todo项。
      this.allCheckbox.checked = !remaining;
    },

    // Add a single todo item to the list by creating a view for it, and
    // appending its element to the `<ul>`.
    addOne: function( todo ) {
      var view = new app.TodoView({ model: todo });
      
      
      //所有的视图都拥有一个 DOM 元素（el 属性），即使该元素仍未插入页面中去。 
      //视图可以在任何时候渲染，然后一次性插入 DOM 中去，这样能尽量减少 reflows 和 repaints 从而获得高性能的 UI 渲染。 
      //this.el 可以从视图的 tagName, className, id 和 attributes 创建，如果都未指定，el 会是一个空 div。
      $('#todo-list').append( view.render().el );
      //this.$list.append(view.render().el);//new
  
    },

   
    //我们可以用addAll()方法里面的this来表示AppView视图，因为listenTo()方法在创建捆绑的时候，隐式的将回调的上下文设置成了该视图。
    addAll: function() {
      this.$('#todo-list').html('');
      
      //_.each()遍历list中的所有元素，按顺序用遍历输出每个元素。
      app.Todos.each(this.addOne, this);
    },

    
    filterOne : function (todo) {
      todo.trigger('visible');//?????????????
    },

    // New
    filterAll : function () {
      app.Todos.each(this.filterOne, this);
    },


    // New
    // Generate the attributes for a new Todo item.
    //val() 方法返回或设置被选元素的值。
    //jQuery.trim()函数的返回值为String类型，返回去除两端空白字符串后的字符串。
    newAttributes: function() {
      return {
        title: this.$input.val().trim(),
        order: app.Todos.nextOrder(),
        completed: false
      };
    },

    // 用户在<input/>元素上按回车键的时候，创建一个新的Todo模型，并将它保存在localStorage中，并且重置<input/>元素，以便创建下一个todo项。
    // Todo模型通过newAttirbutes()进行填充，该方法返回一个由新todo项的title，order，completed组成的对象字面量。
    // 因为回调是通过events哈希邦定的，所以this指向的是视图，而不是DOM元素。
    
    //which属性用于返回触发当前事件时按下的键盘按键或鼠标按钮。
    //对于键盘和鼠标事件，该属性用于确定你按下的是哪一个键盘按键或鼠标按钮。
    createOnEnter: function( event ) {
      if ( event.which !== ENTER_KEY || !this.$input.val().trim() ) {
        return;
      }

      app.Todos.create( this.newAttributes() );
      this.$input.val('');
    },

    //当用户选中clear-completed复选框(该复选框由#stats-template填充在footer里)的时候，删除todo列表里所有标记为已完成的todo项。
    //_.invoke(list, methodName, *arguments) 
    //在list的每个元素上执行methodName方法。 任何传递给invoke的额外参数，invoke都会在调用methodName方法的时候传递给它。
  
    clearCompleted: function() {
      _.invoke(app.Todos.completed(), 'destroy');
      return false;
    },

    // 通过选中toggle-all复选框，允许用户将todo列表中的所有todo项，都标记为已完成。
    toggleAllComplete: function() {
      var completed = this.allCheckbox.checked;

      app.Todos.each(function( todo ) {
        todo.save({
          'completed': completed
        });
      });
    }
  });
