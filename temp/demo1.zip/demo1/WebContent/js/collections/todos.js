var app = app || {};

	
	
  // TodoList用于组织我们的模型。该集合使用localStorage适配器来覆盖Backbone的默认的sync()
  //用于将todo项保存到HTML5的localStorage,通过localStorage可以在页面请求建保存它们
  // ---------------

  // The collection of todos is backed by *localStorage* instead of a remote
  // server.
  var TodoList = Backbone.Collection.extend({

    // Reference to this collection's model.
    model: app.Todo,

    // Save all of the todo items under the `"todos-backbone"` namespace.
    localStorage: new Backbone.LocalStorage('todos-backbone'),

    //  已完成todo项的数组    Filter down the list of all todo items that are finished.

    
    completed: function() {
      return this.filter(function( todo ) {
        return todo.get('completed');
      });
    },
    
    
//    completed: function(){
//    	return this.where({completed: true});
//    },

    //  未完成todo项的数组     Filter down the list to only todo items that are still not finished.
    //_.without(array,values)返回一个删除所有values值后的array副本。
    remaining: function() {
      return this.without.apply( this, this.completed() );
    },
    
//    remaining: function(){
//    	return this.where({completed: false});
//    },
    

    // We keep the Todos in sequential order, despite being saved by unordered
    // GUID in the database. This generates the next order number for new items.
    //nextOrder()方法实现了一个序列产生器，
    nextOrder: function() {
      if ( !this.length ) {
        return 1;
      }
      return this.last().get('order') + 1;
    },
//    nextOrder:function(){
//    	return this.length ? this.last().get('order')+1 : 1;
//    },

    // Todos are sorted by their original insertion order.
    //comparator()方法通过其todo项的插入顺序(order)对集合进行排序
    comparator: function( todo ) {
      return todo.get('order');
    }
//    comparator: 'order'
  });

  // Create our global collection of **Todos**.
  app.Todos = new TodoList();
  
